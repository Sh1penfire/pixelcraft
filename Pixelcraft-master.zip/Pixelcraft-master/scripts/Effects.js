const healedStatus = extendContent(StatusEffect, "healed");
healedStatus.speedMultiplier = 2;
healedStatus.armorMultiplier = .5;
healedStatus.damage = -1;
healedStatus.effect = healBlockFull;
healedStatus.colour  = green;
                                                            
